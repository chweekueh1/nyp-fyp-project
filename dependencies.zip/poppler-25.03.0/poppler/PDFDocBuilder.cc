//========================================================================
//
// PDFDocBuilder.cc
//
// This file is licensed under the GPLv2 or later
//
// Copyright 2020 Albert Astals Cid <aacid@kde.org>
//
//========================================================================

#include "PDFDocBuilder.h"

PDFDocBuilder::~PDFDocBuilder() = default;
